//JAVA 111
//SPRING 2018
//CCAC NORTH CAMPUS
//Professor: Jeff Seaman
//Group: Caroline Cwalina, Erik Wingfield, Dylan Smith, AJ, Joe


package application;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
//Create the Main Application to house the Stage and all the Scenes
public class Main extends Application {
	private Stage primaryStage;
	private static BorderPane mainLayout;
//Set the main Stage with the first default Welcome Scene
//Lines 22-46 are all setting the main stage, borderpane and setting Scene 1 as the default scene
	@Override
	public void start(Stage primaryStage) throws IOException {
		this.primaryStage = primaryStage;
		this.primaryStage.setTitle("Health App");
		
		showMainBorderPane();
		showScene1();		
	}
	
	public void showMainBorderPane() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("MainBorderPane.fxml"));
		mainLayout = loader.load();
		Scene scene = new Scene(mainLayout);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void showScene1() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("Scene1Welcome.fxml"));
		BorderPane welcomePane = loader.load();
		mainLayout.setCenter(welcomePane);
	}
	//Methods 2-6 call the rest of the scenes and will be linked to the respective buttons in controllers
	//All have to load a new FXML Loader and locate the correct fxml of the desired scene
	//Once the new scene is retrieved and loaded then it is centered
	public static void showScene2() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("Scene2Muscle.fxml"));
		BorderPane scene2Pane = loader.load();
		mainLayout.setCenter(scene2Pane);
	}
	
	public static void showScene3() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("Scene3Back.fxml"));
		BorderPane scene3Pane = loader.load();
		mainLayout.setCenter(scene3Pane);
	}
	
	public static void showScene4() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("Scene4Abs.fxml"));
		BorderPane scene4Pane = loader.load();
		mainLayout.setCenter(scene4Pane);
	}
	
	public static void showScene5() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("Scene5Legs.fxml"));
		BorderPane scene5Pane = loader.load();
		mainLayout.setCenter(scene5Pane);
	}
	
	
	public static void showScene6() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("Scene6Calorie.fxml"));
		BorderPane scene6Pane = loader.load();
		mainLayout.setCenter(scene6Pane);
	}
	
//Run the program	
	public static void main(String[] args) {
		launch(args);
	}
}
