package application;

//This controls the Scene 2 Muscle Selection Javafx Page and all the Widgets on it

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class Scene2Muscle {
	
	//Import all the used FXML categories and the fx id I gave them on SceneBuilder
	
	@FXML
	public BorderPane muscleBorder; 
	
	@FXML
	public AnchorPane muscleAnchor; 
	
	@FXML
	public Label textLabel; 
	
	@FXML
	public Label progressLabel; 
	
	@FXML
	public ImageView muscleImage; 
	
	@FXML
	public Button muscleBackButton; 
	
	@FXML
	public RadioButton absRadio; 
	
	@FXML
	public RadioButton backRadio; 
	
	@FXML
	public RadioButton legsRadio; 
	
	@FXML
	public CheckBox absCheck; 
	
	@FXML
	public CheckBox backCheck; 
	
	@FXML
	public CheckBox legsCheck; 
	
	@FXML
	public ToggleGroup muscle; 
	
	//Create an ActionEvent method for the radio buttons
	//Use if statements to differentiate between the buttons
	//The is selected built in function allows for the scene change main methods to be 
	// executed when the right radio button is clicked
	
	public void radioSelect(ActionEvent event) throws IOException {
		if (absRadio.isSelected()) {
			Main.showScene4();
		}
		if (backRadio.isSelected()) {
			Main.showScene3();
		}
		if (legsRadio.isSelected()) {
			Main.showScene5();
		}
	}
	
	//Create the method for the Button to go back to welcome screen
	//The methods call the appropriate scene change from the main javafx doc 
	
	@FXML
	public void goBackToWelcomefrMuscle() throws IOException {
		Main.showScene1();
	}
	
	
}
