package application;


//This controls the Scene 1 Welcome  Javafx Page and all the Widgets on it

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
public class Scene1WelcomeController {
	
	//Import all the used FXML categories and the fx id I gave them on SceneBuilder
	
	@FXML
	private BorderPane scene1BorderPane;
	
	@FXML
	private AnchorPane scene1AnchorPane;
	
	@FXML
	private Text welcomeText;
	
	@FXML
	private ImageView welcomeImge;
	
	@FXML
	private TextField nameTextField;
	
	@FXML
	private Label welcomeLabel;
	
	@FXML
	private SplitMenuButton mainDropDown;
	
	@FXML
	private MenuItem workoutMenu;
	
	@FXML
	private MenuItem calorieMenu;
	
	//Create the two methods for the two MenuItem in the Split Menu Button
	//The methods call the appropriate scene change from the main javafx doc
	
	@FXML
	public void goMuscle() throws IOException {
		Main.showScene2();
	}
	
	@FXML
	public void goCalorie() throws IOException {
		Main.showScene6();
		
	}
	

}
