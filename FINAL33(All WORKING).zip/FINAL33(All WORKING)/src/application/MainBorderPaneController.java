package application;

import javafx.fxml.FXML;
import javafx.scene.layout.BorderPane;
//Controller for the main border pain. Only have to import the FXML BorderPane
public class MainBorderPaneController {
	
	@FXML
	private BorderPane mainStage;

}
