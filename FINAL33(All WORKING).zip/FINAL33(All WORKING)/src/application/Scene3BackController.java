package application;

//This controls the Scene 3 Back Javafx Page and all the Widgets on it

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;

public class Scene3BackController {
	
	//Import all the used FXML categories and the fx id I gave them on SceneBuilder
	
	@FXML
	private BorderPane scene3BorderPane;
	
	@FXML
	private AnchorPane scene3AnchorPane;
	
	@FXML
	private ImageView backImage;
	
	@FXML
	private Button backscButton;
	
	@FXML
	private Hyperlink backHyperlink;
	
	@FXML
	private Text backexcercisText;
	
	//Create the method for the Button to go back to Muscle Selection screen
	//The methods call the appropriate scene change from the main javafx doc
	
	@FXML
	public void goBackToMusclefrBack() throws IOException {
		Main.showScene2();
	}
	
	//After importing the awt.Desktop and URI library the get desktop function can be used
	//This method is set so that when the hyperlink is clicked it initiates the default browser
	//and brings up the coded URL
	//this works because hyperlink in java is just a button that is straight text
	//the on action method is coded in Scenebuilder to be this URL opener
	
	@FXML
	public void onClickBack() throws IOException, URISyntaxException {
		Desktop d = Desktop.getDesktop();
		d.browse(new URI("https://www.youtube.com/watch?v=kcCG2-KEGEQ&list=PLpBQy2MBM7U-q9U4zMomynKnbXmEDG8AK"));
	}

	

}
