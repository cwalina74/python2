package application;

//This controls the Scene 6 Calorie Counter Javafx Page and all the Widgets on it

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;

public class Scene6CalorieController {
	
	//Import all the used FXML categories and the fx id I gave them on SceneBuilder
	
	@FXML
	private BorderPane scene6BorderPane;
	
	@FXML
	private AnchorPane scene6AnchorPane;
	
	@FXML
	private Text calorieLabel;
	
	@FXML
	private Label breakfastLabel;
	
	@FXML
	private Label lunchLabel;
	
	@FXML
	private Label dinnerLabel;
	
	@FXML
	private Label snacksLabel;
	

	@FXML
	private Label excercisLabel;
	
	@FXML
	private TextField breakfastTextField;
	
	@FXML
	private TextField lunchTextField;
	
	@FXML
	private TextField dinnerTextField;
	
	@FXML
	private TextField snacksTextField;
	
	@FXML
	private TextField excerciseTextField;
	
	@FXML
	private Label caltotalLabel;
	
	@FXML
	private Label totalLabel;
	
	@FXML
	private Button backfrcalButton;
	
	@FXML
	private Button calculateButton;
	
	//Create the method for the Button to go back to welcome screen
	//The methods call the appropriate scene change from the main javafx doc 
	
	@FXML
	public void goBackToWelcomefrCal() throws IOException {
		Main.showScene1();
	}
	
	
	//This method is meant to function with the Calculate Button is clicked
	//It is to take the input of the user on the calories they ate and 
	//exercised and give them a total count for the day
	//Output is the total displayed in a label
	
	@FXML
	public void onClaculateClick() throws IOException {
		
		//declare local variables. 13 calorie per min of exercise is the average burned according to Google.
		int CALORIE_BURNED_PER_MIN = 13;
		
		//Get the input from the user
		String breakfast = breakfastTextField.getText();
		String lunch = lunchTextField.getText();
		String dinner = dinnerTextField.getText();
		String snacks = snacksTextField.getText();
		String excercise = excerciseTextField.getText();
		
		//Convert the input to integer for calculator use
		int breakfastint = Integer.parseInt(breakfast);
		int lunchint = Integer.parseInt(lunch);
		int dinnerint = Integer.parseInt(dinner);
		int snacksint = Integer.parseInt(snacks);
		int excerciseint = Integer.parseInt(excercise);
		
		//Calculate the total net calories for the day from the converted integer user input
		//Add what calories were consumed and subtract the calories burned exercising 
		//Calories burned is equal to minutes exercised multiplied by the conversion factor
		double total = (breakfastint + lunchint + dinnerint + snacksint) -(CALORIE_BURNED_PER_MIN * excerciseint);
		
		//Change the total net calories back to string for output display
		String stringtotal = String.valueOf(total);
		
		//display the output in the alloted label
		caltotalLabel.setText(stringtotal);
	}
	

}
