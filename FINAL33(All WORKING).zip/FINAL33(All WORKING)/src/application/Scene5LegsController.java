package application;

//This controls the Scene 5 Back Javafx Page and all the Widgets on it

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class Scene5LegsController {
	
	//Import all the used FXML categories and the fx id I gave them on SceneBuilder
	
	@FXML
	private BorderPane scene5BorderPane;
	
	@FXML
	private AnchorPane scene5AnchorPane;
	
	@FXML
	private ImageView legsImage;
	
	@FXML
	private Button legsbackButton;
	
	@FXML
	private Hyperlink legsHyperlink;
	
	@FXML
	private Label legsLabel;
	
	//Create the method for the Button to go back to Muscle Selection screen
	//The methods call the appropriate scene change from the main javafx doc
	
	@FXML
	public void goBackToMusclefrLegs() throws IOException {
		Main.showScene2();
	}
	
	//After importing the awt.Desktop and URI library the get desktop function can be used
	//This method is set so that when the hyperlink is clicked it initiates the default browser
	//and brings up the coded URL
	//this works because hyperlink in java is just a button that is straight text
	//the on action method is coded in Scenebuilder to be this URL opener
		
	@FXML
	public void onClickLegs() throws IOException, URISyntaxException {
		Desktop d = Desktop.getDesktop();
		d.browse(new URI("https://www.youtube.com/watch?v=hEAXg2r_vMQ&list=PLDEF03F9ADE52F517"));
	}
	

}
